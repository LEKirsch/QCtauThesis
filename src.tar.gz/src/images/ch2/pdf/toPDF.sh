#!/bin/bash
for file in $(ls *.png | cut -d'.' -f1); do convert $file.png $file.pdf ; done
for file in $(ls *.jpg | cut -d'.' -f1); do convert $file.jpg $file.pdf ; done

#!/bin/bash
echo "Converting PDF..."

#cd ch2
#for file in $(ls *.png | cut -d'.' -f1); do convert $file.png pdf/$file.pdf ;
#done

cd ../
cd ch3
for file in $(ls *.png | cut -d'.' -f1); do convert $file.png pdf/$file.pdf ; done

#!/bin/bash
echo "Converting PDF..."

cd ch1
for file in $(ls *.png | cut -d'.' -f1); do convert $file.png pdf/$file.pdf ;
done

#cd ../
#cd ch2
#for file in $(ls *.png | cut -d'.' -f1); do convert $file.png pdf/$file.pdf ; 
#done

#cd ../
#cd ch3
#for file in $(ls *.png | cut -d'.' -f1); do convert $file.png pdf/$file.pdf ; 
#done

cd ../
cd ch4
for file in $(ls *.png | cut -d'.' -f1); do convert $file.png pdf/$file.pdf ; 
done

#cd ../
#cd ch5
#for file in $(ls *.png | cut -d'.' -f1); do convert $file.png pdf/$file.pdf ; 
#done
